module.exports = {
    database: "mongodb://localhost:27017/elect",
    secret: 's e c r e c y',
    port: 8080,
    host: '0.0.0.0'
}